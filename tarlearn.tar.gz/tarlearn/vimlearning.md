Hi,this is a test sample for vim editor!

insert:-------i1a--------
insert:-------i1a--------
insert:-------i1a--------
o
o
o
